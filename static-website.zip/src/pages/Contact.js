import React from "react";
import "../assets/styles/Contact.css";

const Contact = () => {
  return (
    <div className="fu-contact-section py-5">
      <div className="container">
        <div className="text-center mb-4">
          <h2>Contact Us</h2>
          <p className="mt-2">
            We'd love to hear from you! Please fill out the form below and our team will get in touch soon.
          </p>
        </div>

        <div className="fu-contact-form mx-auto">
          <form>
            <div className="row g-3">
              <div className="col-md-6">
                <input
                  type="text"
                  className="form-control fu-contact-input"
                  placeholder="Your Name"
                  required
                />
              </div>
              <div className="col-md-6">
                <input
                  type="email"
                  className="form-control fu-contact-input"
                  placeholder="Your Email"
                  required
                />
              </div>
              <div className="col-12">
                <input
                  type="text"
                  className="form-control fu-contact-input"
                  placeholder="Subject"
                />
              </div>
              <div className="col-12">
                <textarea
                  className="form-control fu-contact-textarea"
                  rows="4"
                  placeholder="Your Message"
                  required
                ></textarea>
              </div>
              <div className="col-12 text-center">
                <button type="submit" className="fu-contact-btn mt-3">
                  Send Message
                </button>
              </div>
            </div>
          </form>
        </div>

        <div className="text-center mt-5">
          <p>
            <strong>Email:</strong> v4utaxsolutions@yahoo.com 
          </p>
          <p>
            <strong>Phone:</strong> +91 9347023562
          </p>
        </div>
      </div>
    </div>
  );
};

export default Contact;
